/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_0655909312_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0655909312", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0655909312.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3034617094_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3034617094", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3034617094.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3868638720_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3868638720", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3868638720.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1970162374_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1970162374", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1970162374.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0529133301_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0529133301", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0529133301.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0237204547_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0237204547", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0237204547.didat");
}
