/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "x = %d, y = %d";
static const char *ng1 = "D:/COA_LAB_TEST_20CS30037/Divby255_tb.v";
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {2550U, 0U};
static unsigned int ng4[] = {255U, 0U};
static unsigned int ng5[] = {3825U, 0U};

void Monitor_42_2(char *);
void Monitor_42_2(char *);


static void Monitor_42_2_Func(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 1448);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    xsi_vlogfile_write(1, 0, 3, ng0, 3, t0, (char)118, t3, 32, (char)118, t5, 32);

LAB1:    return;
}

static void Cont_32_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 2368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(32, ng1);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3264);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t2, 8);
    xsi_driver_vfirst_trans(t3, 0, 31);

LAB1:    return;
}

static void Initial_41_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;

LAB0:    t1 = (t0 + 2616U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng1);

LAB4:    xsi_set_current_line(42, ng1);
    Monitor_42_2(t0);
    xsi_set_current_line(44, ng1);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(44, ng1);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 1448);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    xsi_set_current_line(45, ng1);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(45, ng1);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 1448);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    xsi_set_current_line(46, ng1);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(46, ng1);
    t3 = ((char*)((ng5)));
    t4 = (t0 + 1448);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    xsi_set_current_line(47, ng1);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(48, ng1);
    xsi_vlog_finish(1);
    goto LAB1;

}

void Monitor_42_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2672);
    t2 = (t0 + 3184);
    xsi_vlogfile_monitor((void *)Monitor_42_2_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000004199597616_1749812794_init()
{
	static char *pe[] = {(void *)Cont_32_0,(void *)Initial_41_1,(void *)Monitor_42_2};
	xsi_register_didat("work_m_00000000004199597616_1749812794", "isim/Divby255_tb_isim_beh.exe.sim/work/m_00000000004199597616_1749812794.didat");
	xsi_register_executes(pe);
}
